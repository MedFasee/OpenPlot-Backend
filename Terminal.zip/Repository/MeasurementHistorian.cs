﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using OpenPlot.Ingestor.Gsf.Data;
using OpenPlot.Ingestor.Gsf.Utils;

namespace OpenPlot.Ingestor.Gsf.Repository
{
    public class MeasurementHistorian : Database, IMeasurementDb
    {
        private static readonly HttpClient httpClient = new HttpClient();

        readonly string connectionString;
        readonly string connectionStringHTTPS = string.Empty;

        public MeasurementHistorian(string ip, int port, string user, string pass) : base(ip, user, pass)
        {
            connectionString = "http://" + ip + ":" + port + "/historian/timeseriesdata/read/historic/";

            if (ip.ToLower().Contains("https"))
            {
                connectionString = ip.Replace("https://", "http://") + ":" + port + "/historian/timeseriesdata/read/historic/";

                if (port == 6156)
                    connectionStringHTTPS = ip + "/historian/timeseriesdata/read/historic/";
            }
        }

        public Dictionary<Channel, ITimeSeries> QueryTerminalSeries(string Id, DateTime start, DateTime finish, List<Channel> measurements, int dataRate, int equipmentRate, bool downloadStat = false)
        {
            Console.WriteLine("QueryTerminal");
            Console.Out.Flush();

            var builtMeasurements = new Dictionary<int, Channel>();

            foreach (Channel channel in measurements)
                builtMeasurements[channel.Id] = channel;

            string channels = GetChannels(measurements);
            string path = BuildPath(start, finish, channels);

            if (!string.IsNullOrEmpty(connectionStringHTTPS))
            {
                string pathHTTPS = BuildPathHTTPS(start, finish, channels);

                try
                {
                    Task<string> queryTask = httpClient.GetStringAsync(pathHTTPS);
                    return ParseJson(queryTask, builtMeasurements, dataRate, downloadStat);
                }
                catch (Exception e)
                {
                    try
                    {
                        Task<string> queryTask = httpClient.GetStringAsync(path);
                        return ParseJson(queryTask, builtMeasurements, dataRate, downloadStat);
                    }
                    catch (Exception)
                    {
                        HandleQueryException(e);
                    }
                }
            }

            try
            {
                Task<string> queryTask = httpClient.GetStringAsync(path);
                return ParseJson(queryTask, builtMeasurements, dataRate, downloadStat);
            }
            catch (Exception e)
            {
                HandleQueryException(e);
            }

            throw new InvalidQueryException(InvalidQueryException.BAD_HIST_QUERY);
        }

        private void HandleQueryException(Exception e)
        {
            if (e.InnerException != null)
            {
                if (e.InnerException is HttpRequestException)
                {
                    if (e.InnerException.HResult == -2147467259)
                        throw new InvalidConnectionException(Ip);
                    if (e.InnerException.HResult == -2146233088)
                        throw new InvalidQueryException(InvalidQueryException.BAD_HIST_QUERY);
                }

                if (e.InnerException is TaskCanceledException && e.InnerException.HResult == -2146233029)
                    throw new QueryTimeoutException();

                throw new InvalidQueryException(e.InnerException.Message);
            }

            throw new InvalidQueryException(e.Message);
        }

        private string BuildPath(DateTime start, DateTime finish, string channels)
        {
            return connectionString + channels + "/" + start.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "/" + finish.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "/json";
        }

        private string BuildPathHTTPS(DateTime start, DateTime finish, string channels)
        {
            return connectionStringHTTPS + channels + "/" + start.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "/" + finish.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "/json";
        }

        private static string GetChannels(List<Channel> measurements)
        {
            var seen = new HashSet<int>();
            var sb = new StringBuilder();

            foreach (var ch in measurements)
            {
                if (seen.Add(ch.Id))
                {
                    if (sb.Length > 0)
                        sb.Append(',');

                    sb.Append(ch.Id);
                }
            }

            return sb.ToString();
        }

        private static Dictionary<Channel, ITimeSeries> ParseJson(
            Task<string> query,
            Dictionary<int, Channel> measurementsById,
            double framesPerSecond,
            bool downloadStat)
        {
            query.Wait();

            string jsonData = query.Result;

            if (jsonData == "{\"TimeSeriesDataPoints\":[]}")
                throw new InvalidQueryException(InvalidQueryException.EMPTY);

            var series = new Dictionary<Channel, ITimeSeries>(measurementsById.Count + (downloadStat ? 1 : 0));
            foreach (var ch in measurementsById.Values)
                series[ch] = new TimeSeries();

            if (downloadStat && !series.ContainsKey(Channel.MISSING))
                series[Channel.MISSING] = new TimeSeries();

            bool hasData = false;
            double frameMs = 1000.0 / framesPerSecond;

            byte[] utf8 = Encoding.UTF8.GetBytes(jsonData);
            var reader = new Utf8JsonReader(utf8, isFinalBlock: true, state: default);

            int historianId = 0;
            DateTime measureTime = default;
            double value = 0;
            int qualityCode = 0;
            bool gotId = false, gotTime = false, gotValue = false, gotQuality = false;

            while (reader.Read())
            {
                if (reader.TokenType == JsonTokenType.PropertyName)
                {
                    if (reader.ValueTextEquals("TimeSeriesDataPoints"))
                    {
                        reader.Read();
                        continue;
                    }

                    if (reader.ValueTextEquals("HistorianID"))
                    {
                        reader.Read();
                        historianId = reader.GetInt32();
                        gotId = true;
                        continue;
                    }

                    if (reader.ValueTextEquals("Time"))
                    {
                        reader.Read();
                        string t = reader.GetString()!;
                        t = t.TrimStart();

                        gotTime = DateTime.TryParseExact(
                            t,
                            "yyyy-MM-dd HH:mm:ss.fff",
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.None,
                            out measureTime);

                        continue;
                    }

                    if (reader.ValueTextEquals("Value"))
                    {
                        reader.Read();
                        value = reader.GetDouble();
                        gotValue = true;
                        continue;
                    }

                    if (reader.ValueTextEquals("Quality"))
                    {
                        reader.Read();
                        qualityCode = reader.GetInt32();
                        gotQuality = true;
                        continue;
                    }
                }

                if (reader.TokenType == JsonTokenType.EndObject)
                {
                    if (gotId && gotTime && gotValue && gotQuality)
                    {
                        double timeModulus = measureTime.Millisecond % frameMs;
                        double timeModulusDiff = Math.Abs(frameMs - timeModulus);

                        if (timeModulus < 2 || timeModulusDiff < 2)
                        {
                            bool qualityOk = qualityCode == 29;

                            if (measurementsById.TryGetValue(historianId, out var key) && key is not null)
                            {
                                hasData = true;

                                double time = TimeUtils.OaDate(measureTime);
                                series[key].Add(time, value, qualityCode);

                                if (!qualityOk && downloadStat)
                                    series[Channel.MISSING].Add(time, 2, qualityCode);
                            }
                        }
                    }

                    historianId = 0;
                    measureTime = default;
                    value = 0;
                    qualityCode = 0;
                    gotId = gotTime = gotValue = gotQuality = false;
                }
            }

            if (!hasData)
                throw new InvalidQueryException(InvalidQueryException.EMPTY);

            return series;
        }
    }
}